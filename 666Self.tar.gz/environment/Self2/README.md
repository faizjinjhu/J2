# KoplaxsSelfBot
Koplaxs Self Bot
Basic Sc By : LINE TCR
============================================
Bot Protect Versi Selfbot 1 Self + 2 Assist
============================================
Bot Protect TCR Versi Selfbot
-Siapkan 1 Akun Utama Dan 2 Akun Bot

Fungsinya?
Kelebihan :
1.Protect Group Line Pastinya
2.Bisa Invite Semua Bot Lewat Command Tanpa Bot Induk
3.Bot Tidak Saling Kick Ketika Ada Yang Terkick

Kelemahan:
1.Command Tidak Bisa Dipakai oleh Orang Lain
2.Jika Ingin Protect Lebih Dari 1 Group, Kalian Wajib ada di Semua Group Tersebut

Cara Instal :
- pkg install python2 -y
- pkg install git -y
- git clone https://github.com/koplaxs/KoplaxsSelf
- pip2 install rsa
- pip2 install thrift==0.9.3
- pip2 install requests

Cara Menjalankan Botnya :
- cd KoplaxsSelf
- python KoplaxsSelf.py
Video Tutorial :
https://youtu.be/Isqse24n8GA


Ada Pertanyaan?
Add My Line => @hanavy1992

Thanks For :
- Alfathdirk
- Farzain
- Dan Kawan²
